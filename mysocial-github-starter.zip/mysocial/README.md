# mySocial

A responsive social link-in-bio website starter. Includes 21 platform fields, live preview, Supabase email/password authentication, public profile lookup (`?u=username`), and SQL row-level security policies.

## Publish from a phone
1. Create a public repository at https://github.com/new named `mysocial`.
2. Upload `index.html` to the repository root and commit it. Upload the `supabase` folder too so you can access `schema.sql`.
3. Open repository Settings → Pages → Build and deployment → Deploy from a branch. Select `main` and `/(root)`, then Save.
4. Create a project at https://supabase.com/.
5. In Supabase SQL Editor, run the contents of `supabase/schema.sql`.
6. In Supabase Project Settings / API, copy the Project URL and publishable key (or legacy anon key). In `index.html`, replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY` with those values.
7. Commit the changed `index.html` to GitHub.
8. In Supabase Authentication → URL Configuration, set Site URL and Redirect URLs to your GitHub Pages site, e.g. `https://YOUR-USERNAME.github.io/mysocial/`.
9. Open the published site, create a mySocial account, confirm your email if requested, sign in, add links and save. Share your page as `https://YOUR-USERNAME.github.io/mysocial/?u=yourname`.

## Security notes
- Never put Supabase service-role keys or database passwords in the browser code. Only the publishable/anon key is intended for public clients; row-level security protects writes.
- mySocial does not request or store social platform passwords.
- Profile links are public to anyone. Do not put private information in your profile.
- Some platforms may open in a browser instead of their app, depending on the device, app installation, and platform link handling.
- This starter uses a query-string profile URL (`?u=username`), not a pretty `/username` path.
